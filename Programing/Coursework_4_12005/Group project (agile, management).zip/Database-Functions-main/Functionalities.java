import java.sql.*;

public interface Functionalities {

//At the moment, there will be only sleeping hours and screen time recorded in the database
//----------------------------GENERAL-METHODS------------------------------------------------------
    public void insertData(Date date, float sleepingHours, float screenTime);
    public void deleteData(Date date);
    public String getAllData();
    public String getData(Date date);
//----------------------------SLEEPINGHOURS------------------------------------------------------

    public void updateSleepingHours(Date date,float hours);

    //this method will return the sleeping hours of a given date
    public float getSleepingHours(Date date);

    //this method will return the total sleeping hours of a given interval
    public float getTotalSleepingHours(Date date1, Date date2);

    public float getAverageSleepingHours(Date date1, Date date2);

//----------------------------SCREENTIME------------------------------------------------------
    public void updateScreenTime(Date date,float hours);

    //this method will return the screen time of a given date
    public float getScreenTime(Date date);

    //this method will return the total screen time of a given interval
    public float getTotalScreenTime(Date date1, Date date2);

    public float getAverageScreenTime(Date date1, Date date2);

}
