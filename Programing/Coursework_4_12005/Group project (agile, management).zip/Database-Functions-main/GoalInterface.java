public interface GoalInterface {

     //---------------------------GOALSETTING-----------------------------------------------------
	/**
	* Sets and stores a goal for a number of hours to sleep
	*
	* @param  hours		a goal number of hours for sleep
	*/
	public void setSleepingGoal(float hours);

	/**
	* Sets and stores a goal for a maximum number of screen time hours
	*
	* @param  hours		a goal number of hours for maximum screen time
	*/
    public void setScreenTimeGoal(float hours);
 
    /**
	* Retrieves the user's goal for sleep hours
	*
	* @return  		the goal number of hours for sleep 
	*/
    public float getSleepingGoal();
 
    /**
	* Retrieves the user's goal for screen time hours
	*
	* @return  		the goal number of hours for screen time
	*/
    public float getScreenTimeGoal();
     
     //public void updateSleepingGoal(float hours);
     
     //public void updateScreenTimeGoal(float hours);
    
    /**
	* Retrieves the user's goal for screen time hours
	*
	* @param	hours		number of hours to compare to sleep hours goal
	* @return  		boolean of if hours is greater than or equal to sleep hours goal
	*/ 
    public boolean compareSleepingGoal(float hours);
     
    /**
	* Retrieves the user's goal for screen time hours
	*
	* @param	hours		number of hours to compare to screen time goal
	* @return  		boolean of if hours is less than or equal to screen time goal
	*/
    public boolean compareScreenTimeGoal(float hours);
 
}
