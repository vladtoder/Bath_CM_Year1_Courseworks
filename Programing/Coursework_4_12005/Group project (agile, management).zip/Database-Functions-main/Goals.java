import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Goals implements GoalInterface {

    @Override
    public void setSleepingGoal(float hours) {
    	setGoal("Sleep",hours);
    }

    @Override
    public void setScreenTimeGoal(float hours) {
    	setGoal("Screen",hours);
    }
    
    private void setGoal(String stat,float hours) {
    	if (hours<0) {hours=0;}
    	List<String> goals = new ArrayList<>();
    	
    	try {//gets goals from file
    		goals = Files.readAllLines(Paths.get("goals.txt"));
    	} catch (IOException e) {}
    	
    	for (int i=0; i<goals.size(); i++)
    	{
    		String[] txt = goals.get(i).split(" ");
    		if (txt[0].equals(stat))
    		{
    			goals.remove(i);//removes previous goal
    			break;
    		}
    	}
    	goals.add(stat+" "+hours);//adds new goal
    	
    	try {
			BufferedWriter br = new BufferedWriter (new FileWriter("goals.txt"));
			for (String line : goals) {
				br.write(line + System.lineSeparator());//writes new goals to file
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
    }

    @Override
    public float getSleepingGoal() {
    	return getGoal("Sleep");
    }

    @Override
    public float getScreenTimeGoal() {
    	return getGoal("Screen");
    }
    private float getGoal(String stat) {
    	List<String> goals;
    	try {
			goals = Files.readAllLines(Paths.get("goals.txt"));//gets all goals from file
		} catch (IOException e) {
			return 0;
		}  
    	for (String goal : goals)
    	{
    		String[] txt = goal.split(" ");
    		if (txt[0].equals(stat))//finds the goal for the specific stat
    		{
    			try {
    				return Float.parseFloat(txt[1]);//returns the goal number
    			} catch(NullPointerException | NumberFormatException e)
    			{
    				break;
    			}
    		}
    	}
    	return 0;//no goal/incorrect formatted goal found
    }

    @Override
    public boolean compareSleepingGoal(float hours) {
        if (getSleepingGoal()<=hours)
        {
            return true;
        }
        return false;
    }

    @Override
    public boolean compareScreenTimeGoal(float hours) {
        if (getScreenTimeGoal()>=hours)
        {
            return true;
        }
        return false;
    }
    
}
