import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

public class Graphs {

	private int width=640;
	private int height=480;
	
	public void genDailyGraph() {
		//Generates a Graph comparing the daily sleep and screen time to goals
		//Saves graph as Daily.jpeg
		Date today = new Date();
		Goals goals = new Goals();
		Calendar cal = Calendar.getInstance();
		cal.setTime(today);
		cal.set(Calendar.SECOND,0);
		cal.set(Calendar.MINUTE,0);
		cal.set(Calendar.HOUR,0);
		cal.set(Calendar.MILLISECOND,0);
		
		cal.add(Calendar.DAY_OF_MONTH,-6);
		
		User database = new User();
		DefaultCategoryDataset dataset = new DefaultCategoryDataset( );
		for (int i = 0; i<7;i++) {
			String dayStr = cal.getTime().toString().split(" ")[0];
			java.sql.Date firstDate = new java.sql.Date(cal.getTime().getTime());
			cal.add(Calendar.DAY_OF_MONTH,1);
			java.sql.Date secondDate = new java.sql.Date(cal.getTime().getTime());
			dataset.addValue(database.getAverageSleepingHours(firstDate,secondDate),"Sleep",dayStr);
			dataset.addValue(goals.getSleepingGoal(),"Sleep Goal",dayStr);
			dataset.addValue(database.getAverageScreenTime(firstDate,secondDate),"Screen Time",dayStr);
			dataset.addValue(goals.getScreenTimeGoal(),"Screen Time Goal",dayStr);
		}
		
		JFreeChart lineChart = ChartFactory.createLineChart(null, null, null, dataset,PlotOrientation.VERTICAL,
				true,false,false);
		File lineChartFile = new File("Daily.jpeg");
		
		CategoryPlot plot = lineChart.getCategoryPlot();
		plot.setBackgroundAlpha(0);
		NumberAxis axis = (NumberAxis)plot.getRangeAxis();
		axis.setLowerBound(0);
		axis.setUpperBound(24);
		
		try {
			ChartUtils.saveChartAsJPEG(lineChartFile ,lineChart, width ,height);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	public void genWeeklyGraph() {
		//Generates a Graph comparing the average sleep and screen time per week to goals
		//Saves graph as Weekly.jpeg
		Date today = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(today);
		cal.set(Calendar.SECOND,0);
		cal.set(Calendar.MINUTE,0);
		cal.set(Calendar.HOUR,0);
		cal.set(Calendar.MILLISECOND,0);
		cal.set(Calendar.DAY_OF_WEEK, 2);
		cal.add(Calendar.WEEK_OF_MONTH,-5);
		
		User database = new User();
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		Goals goals = new Goals();
		
		for (int i = 0; i<6;i++) {
			java.sql.Date firstDate = new java.sql.Date(cal.getTime().getTime());
			String[] day = cal.getTime().toString().split(" ");
			String dayStr = day[2] + " " + day[1];
			cal.add(Calendar.WEEK_OF_MONTH,1);
			java.sql.Date secondDate = new java.sql.Date(cal.getTime().getTime());
			dataset.addValue(database.getAverageSleepingHours(firstDate,secondDate),"Sleep",dayStr);
			dataset.addValue(goals.getSleepingGoal(),"Sleep Goal",dayStr);
			dataset.addValue(database.getAverageScreenTime(firstDate,secondDate),"Screen Time",dayStr);
			dataset.addValue(goals.getScreenTimeGoal(),"Screen Time Goal",dayStr);
		}
		JFreeChart lineChart = ChartFactory.createLineChart(null, null, null, dataset,PlotOrientation.VERTICAL,
				true,false,false);
		File lineChartFile = new File("Weekly.jpeg");
		
		CategoryPlot plot = lineChart.getCategoryPlot();
		plot.setBackgroundAlpha(0);
		NumberAxis axis = (NumberAxis)plot.getRangeAxis();
		axis.setLowerBound(0);
		axis.setUpperBound(24);
		
		try {
			ChartUtils.saveChartAsJPEG(lineChartFile ,lineChart, width ,height);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void genMonthlyGraph() {
		//Generates a Graph comparing the average sleep and screen time per month to goals
		//Saves graph as Monthly.jpeg
		Date today = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(today);
		cal.set(Calendar.SECOND,0);
		cal.set(Calendar.MINUTE,0);
		cal.set(Calendar.HOUR,0);
		cal.set(Calendar.MILLISECOND,0);
		
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.add(Calendar.MONTH,-5);
		
		User database = new User();
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		Goals goals = new Goals();
		
		for (int i = 0; i<6;i++) {
			java.sql.Date firstDate = new java.sql.Date(cal.getTime().getTime());
			String day = cal.getTime().toString().split(" ")[1];
			cal.add(Calendar.MONTH,1);
			java.sql.Date secondDate = new java.sql.Date(cal.getTime().getTime());
			dataset.addValue(database.getAverageSleepingHours(firstDate,secondDate),"Sleep",day);
			dataset.addValue(goals.getSleepingGoal(),"Sleep Goal",day);
			dataset.addValue(database.getAverageScreenTime(firstDate,secondDate),"Screen Time",day);
			dataset.addValue(goals.getScreenTimeGoal(),"Screen Time Goal",day);
		}
		JFreeChart lineChart = ChartFactory.createLineChart(null, null, null, dataset,PlotOrientation.VERTICAL,
				true,false,false);
		File lineChartFile = new File("Monthly.jpeg");
		
		CategoryPlot plot = lineChart.getCategoryPlot();
		plot.setBackgroundAlpha(0);
		NumberAxis axis = (NumberAxis)plot.getRangeAxis();
		axis.setLowerBound(0);
		axis.setUpperBound(24);
		
		try {
			ChartUtils.saveChartAsJPEG(lineChartFile ,lineChart, width ,height);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
