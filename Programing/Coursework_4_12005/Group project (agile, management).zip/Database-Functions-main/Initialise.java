import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.SQLException;


public class Initialise {
    public static void main(String args[]) {
        try {
            // Load the JDBC driver for SQLite database
            Class.forName("org.sqlite.JDBC");

            // Establish connection to the database
            try (Connection c = DriverManager.getConnection("jdbc:sqlite:database.db")) {
                System.out.println("Database Opened...\n");

                // Create a statement object to execute SQL queries
                try (Statement stmt = c.createStatement()) {
                    // SQL statement for creating a new table
                    String sql = "CREATE TABLE data (" +
                            "date DATE PRIMARY KEY," +
                            "sleepingHours FLOAT NOT NULL, " +
                            "screenTime FLOAT NOT NULL)";

                    // Execute the SQL statement to create the table
                    stmt.executeUpdate(sql);

                    System.out.println("Table Data Created Successfully!!!");
                }
            }

        } catch (ClassNotFoundException e) {
            // Handle exception if JDBC Driver not found
            System.err.println("JDBC Driver not found: " + e.getMessage());
            System.exit(1);
        } catch (SQLException e) {
            // Handle SQL related exceptions
            System.err.println("SQLException: " + e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            // Handle any other exceptions
            System.err.println("Exception: " + e.getClass().getName() + ": " + e.getMessage());
            System.exit(1);
        }
    }
}
