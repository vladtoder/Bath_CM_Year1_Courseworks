import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import java.sql.Date;

public class Main {

    // Database connection URL
    private static final String DB_URL = "jdbc:sqlite:database.db";
    private static final User user = new User();

    public static Date convertToDate(String dateString) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            java.util.Date utilDate = dateFormat.parse(dateString);
            return new Date(utilDate.getTime());
        } catch (ParseException e) {
            System.err.println("Error parsing date: " + e.getMessage());
            return null;
        }
    }

    public static void main(String args[]) {
        // Try-with-resources to ensure the Scanner is closed after use
        try (Scanner reader = new Scanner(System.in)){
            String flag;
            do {
                // Display menu options
                System.out.println("Select DML Operation For DB...");
                System.out.println("1. Insert\n2. Update\n3. Delete\n4. Select\n5. Exit");
                System.out.print("Enter a choice: ");
                int choice = reader.nextInt();
                reader.nextLine(); // Consume newline left-over

                // Switch case to handle user choice
                switch (choice) {
                    case 1:
                        insertData(reader);
                        break;
                    case 2:
                        updateData(reader);
                        break;
                    case 3:
                        deleteData(reader);
                        break;
                    case 4:
                        selectAllData();
                        break;
                    case 5:
                        System.out.println("Exiting...");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Oops!!! Wrong Choice...");
                        break;
                }

                // Prompt for continuation
                System.out.print("Continue Y OR N? ");
                flag = reader.nextLine().toUpperCase();
            } while (flag.equals("Y")); // Continue until user opts out
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
        }
    }

    // Method to insert data into the database
    private static void insertData(Scanner reader) {
        try {
            System.out.println("Enter Date (YYYY-MM-DD):");
            String dateString = reader.nextLine();
            Date date = convertToDate(dateString); // Convert string to java.sql.Date

            if (date == null) {
                System.out.println("Invalid date format.");
                return; // Stop execution if date conversion fails
            }

            System.out.println("Enter Sleeping Hours:");
            float sleepingHours = reader.nextFloat();

            System.out.println("Enter Screen Time:");
            float screenTime = reader.nextFloat();
            reader.nextLine(); // Consume newline

            user.insertData(date, sleepingHours, screenTime); // Correctly pass a Date object
        } catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
            reader.nextLine(); // Consume newline to reset scanner state in case of an input mismatch exception
        }
    }
    

    // Method to update existing data
    private static void updateData(Scanner reader) {
    	try {
	        // Input prompts for updating data
	        System.out.println("Enter Date to Update (YYYY-MM-DD):");
	        String dateString = reader.nextLine();
	        Date date = convertToDate(dateString);
	        System.out.println("Enter New Sleeping Hours:");
	        float sleepingHours = reader.nextFloat();
	        System.out.println("Enter New Screen Time:");
	        float screenTime = reader.nextFloat();
	        reader.nextLine(); // Consume newline
	
	        user.updateSleepingHours(date, sleepingHours);
	        user.updateScreenTime(date, screenTime);
    	} catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
            reader.nextLine(); // Consume newline to reset scanner state in case of an input mismatch exception
    	}
    }

    // Method to delete data based on date
    private static void deleteData(Scanner reader) {
    	try {
	        System.out.println("Enter Date to Delete (YYYY-MM-DD):");
	        String dateString = reader.nextLine();
	        Date date = convertToDate(dateString);
	        // Delete query with placeholder for date
	        user.deleteData(date);
    	} catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
            reader.nextLine(); // Consume newline to reset scanner state in case of an input mismatch exception
    	}
    }

    // Method to select and display all data
    private static void selectAllData() {
        System.out.println(user.getAllData());
    }
}
