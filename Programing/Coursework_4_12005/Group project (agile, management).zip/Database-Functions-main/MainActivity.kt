package com.example.cscoursework

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.cscoursework.ui.theme.CsCourseworkTheme
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var dbHelper : DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        dbHelper = DBHelper(this)
        var db = dbHelper.getWritableDatabase()

        setContentView(R.layout.home_layout)
    }

    override fun onDestroy() {
        dbHelper.close()
        super.onDestroy()
    }

    fun HomeBtn(view:View){
        setContentView(R.layout.home_layout)
    }

    fun DataBtn(view:View){
        setContentView(R.layout.data_layout)
    }

    fun GoalsBtn(view:View){
        setContentView(R.layout.goals_layout)
    }

    fun HistoryBtn(view:View){
        setContentView(R.layout.history_layout)
    }


    fun SaveBtn(view:View)
    {
        var sleepHours = findViewById<EditText>(R.id.editTextTime).text.toString()
        var screenHours = findViewById<EditText>(R.id.editTextTime2).text.toString()
        var output = findViewById<TextView>(R.id.textView3)

        //TODO: Use regex to check the formatting
        //Regex()
        //dbHelper.insertData("2000-01-02","3","5")

        var d = Date()
        var dForm = SimpleDateFormat("yyyy-MM-dd")
        var date = dForm.format(d.time)

        println(date)

        dbHelper.insertData(date,sleepHours,screenHours)

        var cursor = dbHelper.allData
        for (i in 1.rangeTo(cursor.count)) //rangeTo is inclusive, therefore if you set the starting integer to 1, it will crash
        {
            //Each loop, we move the cursor to the next row
            cursor.moveToNext()
            //We print the all the columns in that row
            println(cursor.getString(0) + ',' + cursor.getString(1) + ',' + cursor.getString(2))
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}



@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    CsCourseworkTheme {
        Greeting("Android")
    }
}