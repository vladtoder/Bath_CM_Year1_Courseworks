# Database-Functions
Main: The interface for testing. <br>
User: All the SQL functions that can be adapt to the users. <br>
Functionalities: The interface displays all methods in Queries. <br>
Initialise: Used to create the defult database. <br>
