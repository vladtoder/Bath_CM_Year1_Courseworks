import java.sql.*;


public class User implements Functionalities{
    private static final String databaseUrl = "jdbc:sqlite:database.db";

    public void insertData(Date date, float sleepingHours, float screenTime){
        String sql = "INSERT INTO data (date, sleepingHours, screenTime) VALUES (?, ?, ?)";
        // Try-with-resources for automatic resource management
        try (Connection conn = DriverManager.getConnection(databaseUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            conn.setAutoCommit(false); // Begin transaction
            // Set parameters and execute update
            ps.setDate(1, date);
            ps.setFloat(2, sleepingHours);
            ps.setFloat(3, screenTime);
            ps.executeUpdate();
            conn.commit(); // Commit transaction
            System.out.println("Inserted Successfully!!!");
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }
    public void deleteData(Date date){
        String sql = "DELETE FROM data WHERE date = ?";
        try (Connection conn = DriverManager.getConnection(databaseUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            conn.setAutoCommit(false); // Begin transaction
            // Set parameters and execute update
            ps.setDate(1, date);
            ps.executeUpdate();
            conn.commit(); // Commit transaction
            System.out.println("Deleted Successfully!!!");
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }
    public String getAllData(){
        String sql = "SELECT * FROM data";
        try (Connection conn = DriverManager.getConnection(databaseUrl);
             Statement stmt = conn.createStatement();
             ResultSet data = stmt.executeQuery(sql)) {
            StringBuilder result = new StringBuilder();
            while (data.next()) {
                result.append("Date: ").append(data.getDate("date")).append("\nSleeping Hours: ").append(data.getFloat("sleepingHours")).append("\nScreen Time: ").append(data.getFloat("screenTime")).append("\n\n");
            }
            return result.toString();
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return null;
    }
    public String getData(Date date){
        String sql = "SELECT * FROM data WHERE date = ?";
        try (Connection conn = DriverManager.getConnection(databaseUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, date);
            ResultSet data = ps.executeQuery();

            return "Date: " + data.getDate("date") + "\nSleeping Hours: " + data.getFloat("sleepingHours") + "\nScreen Time: " + data.getFloat("screenTime");
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return null;
    }


//----------------------------SLEEPINGHOURS------------------------------------------------------
    public void updateSleepingHours(Date date, float hours){
        String sql = "UPDATE data SET sleepingHours = ? WHERE date = ?";
        try (Connection conn = DriverManager.getConnection(databaseUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            conn.setAutoCommit(false); // Begin transaction
            // Set parameters and execute update
            ps.setFloat(1, hours);
            ps.setDate(2, date);
            ps.executeUpdate();
            conn.commit(); // Commit transaction
            System.out.println("Updated Successfully!!!");
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }
    public float getSleepingHours(Date date){
        String sql = "SELECT sleepingHours FROM data WHERE date = ?";
        try (Connection conn = DriverManager.getConnection(databaseUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, date);
            ResultSet sleepingHours = ps.executeQuery();
            return sleepingHours.getFloat("sleepingHours");
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return 0;
    }
    public float getTotalSleepingHours(Date date1, Date date2){
        String sql = "SELECT SUM(sleepingHours) FROM data WHERE date BETWEEN ? AND ?";
        try (Connection conn = DriverManager.getConnection(databaseUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, date1);
            ps.setDate(2, date2);
            ResultSet sleepingHours = ps.executeQuery();
            return sleepingHours.getFloat("sleepingHours");
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return 0;
    }
    public float getAverageSleepingHours(Date date1, Date date2){
        String sql = "SELECT AVG(sleepingHours) FROM data WHERE date BETWEEN ? AND ?";
        try (Connection conn = DriverManager.getConnection(databaseUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, date1);
            ps.setDate(2, date2);
            ResultSet avgSleepingHours = ps.executeQuery();
            return avgSleepingHours.getFloat("AVG(sleepingHours)");
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return 0;
    }


//----------------------------SCREENTIME------------------------------------------------------
    public void updateScreenTime(Date date, float hours){
        String sql = "UPDATE data SET screenTime = ? WHERE date = ?";
        try (Connection conn = DriverManager.getConnection(databaseUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            conn.setAutoCommit(false); // Begin transaction
            // Set parameters and execute update
            ps.setFloat(1, hours);
            ps.setDate(2, date);
            ps.executeUpdate();
            conn.commit(); // Commit transaction
            System.out.println("Updated Successfully!!!");
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }
    public float getScreenTime(Date date){
        String sql = "SELECT screenTime FROM data WHERE date = ?";
        try (Connection conn = DriverManager.getConnection(databaseUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, date);
            ResultSet screenTime = ps.executeQuery();
            return screenTime.getFloat("screenTime");
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return 0;
    }
    public float getTotalScreenTime(Date date1, Date date2){
        String sql = "SELECT SUM(screenTime) FROM data WHERE date BETWEEN ? AND ?";
        try (Connection conn = DriverManager.getConnection(databaseUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, date1);
            ps.setDate(2, date2);
            ResultSet totalScreenTime = ps.executeQuery();
            return totalScreenTime.getFloat("SUM(screenTime)");
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return 0;
    }
    public float getAverageScreenTime(Date date1, Date date2){
        String sql = "SELECT AVG(screenTime) FROM data WHERE date BETWEEN ? AND ?";
        try (Connection conn = DriverManager.getConnection(databaseUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, date1);
            ps.setDate(2, date2);
            ResultSet avgScreenTime = ps.executeQuery();
            return avgScreenTime.getFloat("AVG(screenTime)");
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return 0;
    }
}
